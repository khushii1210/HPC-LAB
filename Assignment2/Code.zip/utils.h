#ifndef UTILS_H
#define UTILS_H
#include <time.h>

void vector_triad_operation(double *x, double *y, double *v, double *S, int Np);
void copy(double *x,double *y, int Np);
void add(double *x,double *y, double *S, int Np);
void dummy(int x);
void scale(double *x,double *y, double *v, int Np);

#endif
